#pragma once
#include<SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
using namespace sf;
class Ship : public sf::Drawable, public sf::Transformable
{
public:
    Ship(int segments, float segmentWidth, float segmentHeight, float posX, float posY)
        : segmentWidth(segmentWidth), segmentHeight(segmentHeight), numSegments(segments), isSelected(false) {
        // Left rounded end
        leftCircle.setRadius(segmentHeight / 2);
        leftCircle.setPointCount(30);
        leftCircle.setFillColor(sf::Color(0, 255, 0)); // Green
        leftCircle.setOrigin(leftCircle.getRadius(), leftCircle.getRadius());
        leftCircle.setPosition(leftCircle.getRadius(), segmentHeight / 2);

        // Body segments
        for (int i = 0; i < segments; ++i) {
            sf::RectangleShape bodySegment(sf::Vector2f(segmentWidth, segmentHeight));
            bodySegment.setFillColor(sf::Color(0, 255, 0));
            bodySegment.setOrigin(0, segmentHeight / 2);
            bodySegment.setPosition(leftCircle.getRadius() + i * segmentWidth, segmentHeight / 2);
            bodySegmentsShapes.push_back(bodySegment);
        }

        // Right rounded end
        rightCircle.setRadius(segmentHeight / 2);
        rightCircle.setPointCount(30);
        rightCircle.setFillColor(sf::Color(0, 255, 0));
        rightCircle.setOrigin(rightCircle.getRadius(), rightCircle.getRadius());
        float rightCircleX = leftCircle.getRadius() + segments * segmentWidth;
        rightCircle.setPosition(rightCircleX, segmentHeight / 2);

        // Capsule dimensions
        capsuleWidth = leftCircle.getRadius() * 2 + segments * segmentWidth;
        setPosition(posX, posY);
    }

    // Set or unset the outline depending on selection state
    void setSelected(bool selected) {
        isSelected = selected;
        if (isSelected) {
            for (auto& segment : bodySegmentsShapes) {
                segment.setOutlineThickness(4);
                segment.setOutlineColor(sf::Color::Green);
            }
            leftCircle.setOutlineThickness(4);
            leftCircle.setOutlineColor(sf::Color::Green);
            rightCircle.setOutlineThickness(4);
            rightCircle.setOutlineColor(sf::Color::Green);
        }
        else {
            for (auto& segment : bodySegmentsShapes) {
                segment.setOutlineThickness(0);
            }
            leftCircle.setOutlineThickness(0);
            rightCircle.setOutlineThickness(0);
        }
    }

   
    void setColour(int R, int G, int B, int transparency) {
        leftCircle.setFillColor(sf::Color(R, G, B, transparency));
        leftCircle.setOutlineColor(sf::Color(R, G, B, transparency));
        rightCircle.setFillColor(sf::Color(R, G, B, transparency));
        rightCircle.setOutlineColor(sf::Color(R, G, B, transparency));
        for (auto& segment : bodySegmentsShapes) {
            segment.setOutlineColor(sf::Color(R, G, B, transparency));
            segment.setFillColor(sf::Color(R, G, B, transparency));
        }
    }
    int getSegments()
    {
        return numSegments;
    }
    // Get the local bounds of the ship
    sf::FloatRect getLocalBounds() const {
        float width = capsuleWidth;         // Total width of the capsule
        float height = segmentHeight;       // Total height of the capsule
        return sf::FloatRect(0.f, 0.f, width, height); // Local bounds in the ship's local coordinate space
    }

    // Check for collision with another ship
    bool intersects(const Ship& other) const {
        return getGlobalBounds().intersects(other.getGlobalBounds());
    }

    // Get the global bounds of the ship (transformed)
    sf::FloatRect getGlobalBounds() const {
        sf::FloatRect localBounds = getLocalBounds();
        sf::Transform transform = getTransform();
        sf::Vector2f topLeft = transform.transformPoint(localBounds.left, localBounds.top);
        sf::Vector2f bottomRight = transform.transformPoint(localBounds.left + localBounds.width, localBounds.top + localBounds.height);
        return sf::FloatRect(topLeft.x, topLeft.y, bottomRight.x - topLeft.x, bottomRight.y - topLeft.y);
    }

protected:
    void draw(sf::RenderTarget& target, sf::RenderStates states) const override {
        states.transform *= getTransform();
        target.draw(leftCircle, states);
        for (const auto& segment : bodySegmentsShapes) {
            target.draw(segment, states);
        }
        target.draw(rightCircle, states);
    }

private:
    float segmentWidth, segmentHeight, capsuleWidth;
    int numSegments;
    sf::CircleShape leftCircle, rightCircle;
    std::vector<sf::RectangleShape> bodySegmentsShapes;
    bool isSelected;
};


struct Board
{
    Sprite grid[10][10];
    Ship ships[5] =
    {
          Ship(3, 8, 8,600, 110), // Ship with 3 segments
          Ship(4, 7,  8, 600, 160), // p=(segm,length,width,x pos, y pos)
          Ship(5, 5, -8, 600, 210),
          Ship(3, 8, 8, 600, 260),
          Ship(2, 10,  8, 600, 310)
          // Ship with 5 segments
    };
};

// Structure for each icon

struct MarkedPoints
{
    Vector2i Coord;
    bool hit;
};

class Spotlight {
private:
    sf::CircleShape spotlight; // The main spotlight
    sf::CircleShape glow;      // The surrounding glow
    std::vector<sf::CircleShape> particles; // Dynamic particles
    sf::Vector2f position;     // Spotlight position
    float radius;              // Spotlight radius

public:
    // Constructor
    Spotlight(float radius) : radius(radius) {
        // Initialize spotlight
        spotlight.setRadius(radius);
        spotlight.setFillColor(sf::Color::Transparent);
        spotlight.setOutlineThickness(20.0f);
        spotlight.setOutlineColor(sf::Color(0, 0, 0, 100));
        spotlight.setOrigin(radius, radius);

        // Initialize glow
        glow.setRadius(radius-20.0f);
        glow.setFillColor(Color::Transparent);
        glow.setOrigin(glow.getRadius(), glow.getRadius());
        glow.setPosition(spotlight.getRadius(), spotlight.getRadius());

    }
};

inline void initializeSpriteGrid(Sprite grid[10][10], Texture& texture, int rows, int cols, float colsize, float rowsize, int offsetx, float scale, int tempoffsety)
{
    int offsety = tempoffsety;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            grid[i][j].setTexture(texture);
            // Position each sprite in the grid
            grid[i][j].setPosition(j * colsize * scale + offsety, i * rowsize * scale + offsetx);

            // Set the texture rectangle for each sprite to extract part of the texture
            grid[i][j].setTextureRect(IntRect(j * colsize, i * rowsize, colsize, rowsize));

            // Scale the sprite to fit the window
            grid[i][j].setScale(scale, scale);
        }
    }
}

inline void draw(RenderWindow& window, Sprite grid[10][10], int rows, int cols, RectangleShape movablesquare)
{
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            window.draw(grid[i][j]);
        }
    }
    window.draw(movablesquare);
}

inline RectangleShape setmovablesq(float colsize, float rowsize, float scale)
{
    RectangleShape movablesquare;
    movablesquare.setSize(Vector2f(colsize, rowsize));
    movablesquare.setScale(scale, scale);

    movablesquare.setOutlineColor(Color::Red);
    scale != 1 ? movablesquare.setOutlineThickness(15.0f) : movablesquare.setOutlineThickness(5.0f);
    movablesquare.setFillColor(Color::Transparent);
    return movablesquare;
}


//box drawing functiona
//
inline void setwoodenbox(Sprite box[1][5], Texture& texturewood, float width, float height, float positionx, float positiony, float colsize, float rowsize)
{
    float scalex = width / texturewood.getSize().x / 2.75;
    float scaley = height / texturewood.getSize().y / 2.75;
    float scale2 = min(scalex, scaley);
    for (int i = 0; i < 5; i++)
    {
        box[0][i].setTexture(texturewood);
        box[0][i].setScale(scale2, scale2);
        box[0][i].setTextureRect(IntRect(i * colsize, 0, colsize, rowsize));
        box[0][i].setPosition(i * colsize * scale2 + positionx, positiony);
    }

}


inline void addingship(float& scaleship, Texture& textureship, float colsize, float rowsize, RectangleShape& ship, float posx, float posy, int level) {
    // Set the sprite's texture
    /*ship.setTexture(textureship);*/

    // Get the size of the texture
    Vector2u size = textureship.getSize();
    ship.setFillColor(Color::Green);
    // Calculate scaling factors
    float scalexship = colsize / static_cast<float>(size.x);
    float scaleyship = rowsize / static_cast<float>(size.y) * level / 5;;
    Vector2f sizeshape(rowsize, colsize);

    ship.setSize(sizeshape);
    // Use the smaller scale to fit within the box
    scaleship = max(scalexship, scaleyship);

    /*ship.setScale(scaleship, scaleship);*/

    // Set the origin to the center of the sprite
    ship.setOrigin(size.x / 2.0f, size.y / 2.0f);

    // Center the sprite within the specified position and size
    ship.setPosition(
        posx + colsize / 2.0f,
        posy + rowsize / 2.0f
    );

}


//void DoesIntersect1(Ship &tempship,Board board,int selectedShipIndex,bool &intersects,bool&sameclicked)
//{
//
//    intersects = 0;
//    FloatRect intersectionArea;
//    for (int i = 0; i < 5; i++)
//    {
//        FloatRect ShipGlobal = board.ships[i].getGlobalBounds();
//        if (tempship.intersects(board.ships[i]))
//        {
//            if (i != selectedShipIndex)
//            {
//                tempship.setColour(255, 0, 0, 200);
//                intersects = 1;
//                break;
//            }
//            else
//            {
//                sameclicked = 1;
//                break;
//            }
//        }
//    }
//    if (!intersects)
//        tempship.setColour(0, 0, 0, 200); // Valid placement
//}

inline void DoesIntersect1(Ship& tempship,Board board, int selectedShipIndex, bool& intersects, bool& sameclicked)
{
    FloatRect rect1 = tempship.getGlobalBounds();
    intersects = 0;
    float intersectionArea = 0;
    FloatRect intersection;
    for (int i = 0; i < 5; i++)
    {
        FloatRect ShipGlobal = board.ships[i].getGlobalBounds();
        if (rect1.intersects(ShipGlobal, intersection))
        {
            intersectionArea = intersection.width * intersection.height;
            if (i != selectedShipIndex && intersectionArea > 0.6f)
            {
                tempship.setColour(255, 0, 0, 200);
                intersects = 1;
                break;
            }
            else
            {
                sameclicked = 1;
                break;
            }
        }
    }
}

inline void validplacement(Ship& tempship, Board board, int selectedShipIndex, bool& intersects, bool& sameclicked, FloatRect boundingboxglobal, FloatRect tempshipglobal, bool& FullyContained)
{
    FullyContained = boundingboxglobal.contains(tempshipglobal.left, tempshipglobal.top) && boundingboxglobal.contains(tempshipglobal.left + tempshipglobal.width, tempshipglobal.top + tempshipglobal.height);
    //*&&boundingboxglobal.contains(tempshipglobal.left+tempshipglobal.width,tempshipglobal.top)*/;


    if (FullyContained)
    {
        sameclicked = 0;
        intersects = 0;

        DoesIntersect1(tempship, board, selectedShipIndex, intersects, sameclicked);

    }
    else
    {
        intersects = 1;
        tempship.setColour(255, 0, 0, 200); // Invalid placement
        cout << "\nShip does not fit in the bounding box.";
        /* cout << "BoundingBox: (" << boundingboxglobal.left << ", " << boundingboxglobal.top
             << ") -> (" << boundingboxglobal.left + boundingboxglobal.width << ", "
             << boundingboxglobal.top + boundingboxglobal.height << ")" << endl;

         cout << "TempShip: (" << tempshipglobal.left << ", " << tempshipglobal.top
             << ") -> (" << tempshipglobal.left + tempshipglobal.width << ", "
             << tempshipglobal.top + tempshipglobal.height << ")" << endl;*/

    }
}

inline RectangleShape setwoodenbox(Texture& texturewood, float width, float height, float positionx, float positiony)
{
    RectangleShape box;
    Vector2f size(width, height);
    box.setSize(size);
    box.setPosition(positionx, positiony);
    box.setTexture(&texturewood);
    return box;
}

inline bool DoesIntersect(const sf::FloatRect& rect1, const sf::FloatRect& rect2, float& intersectionArea) {
    sf::FloatRect intersection;
    if (rect1.intersects(rect2, intersection)) {
        intersectionArea = intersection.width * intersection.height;  // Calculate intersection area
        return true;
    }
    intersectionArea = 0.f;  // No intersection
    return false;
}


inline void ComputerInitialize(int gridval2[10][10], Board board, int shipindex, bool vertical,MarkedPoints CompPosition[5][5])
{
    srand(time(NULL));
    bool placed = 0, available;
    while (!placed)
    {
        placed = 0;
        int row = rand() % 10;
        int col = rand() % 10;
        if (vertical)
        {
            available = 1;
            for (int i = row; i < row + board.ships[shipindex].getSegments() && available; i++)
            {
                if (gridval2[i][col] != 0||i>9)
                {
                    available = 0;
                }
            }
            if (available)
            {
                int count = 0;
                placed = 1;
                for (int i = row; i < row + board.ships[shipindex].getSegments(); i++)
                {
                    gridval2[i][col] = 1;
                    CompPosition[shipindex][count++].Coord =Vector2i( i,col);
                }
            }

        }
        else
        {
            available = 1;
            for (int i = col; i < col + board.ships[shipindex].getSegments() && available; i++)
            {
                if (gridval2[row][i] != 0||i>9)
                {
                    available = 0;
                }
            }
            if (available)
            {
                placed = 1;
                int count = 0;
                for (int i = col; i < col + board.ships[shipindex].getSegments(); i++)
                {
                    placed = 1;
                    gridval2[row][i] = 1;
                    CompPosition[shipindex][count++].Coord = Vector2i(row,i);
                }
            }

        }
    }
}


inline bool AllSunk(MarkedPoints gridpoints[5][5], Vector2i hitpoint,int &shipnum,bool&exists,Board board)
{
    exists = 0;
    bool allsunk = 1;
    shipnum = -1;
    for (int i = 0; i < 5&&!exists; i++)//ships
    {
        for (int j = 0; j < 5&&!exists; j++)//all areas they cover
        {
            if (gridpoints[i][j].Coord== hitpoint)
            {
                cout << "exists" << endl;
                gridpoints[i][j].hit = 1;
                exists = 1;
            }

            if (exists)
            {
                for (int k = 0; k < board.ships[i].getSegments() && allsunk; k++)
                {
                    cout << "checking if all hit...." << endl;
                    shipnum = i;
                    if (gridpoints[i][k].hit != 1)
                    {
                        allsunk = 0;
                    }
                }
                cout << "all sunk?" << allsunk<<endl;
            }
        }
    }
    return allsunk;
}

inline int Lastelement(MarkedPoints player[5][5], int shipnum)
{
    int elem=0;

    while (player[shipnum][elem].Coord != Vector2i(-1, -1))
        elem++;

    return elem;
}


/////menu functions


struct Icon {
    sf::ConvexShape diamond;
    sf::Texture* texture = nullptr;  // Pointer to a texture
    float currentAngle = 1.0f;    // Tracks the position of the diamond along the circular layout.
    bool isZoomedIn = false;
};

// Function to create a simple diamond shape
inline void createDiamond(Icon& icon, float size) {
    icon.diamond.setPointCount(4);
    icon.diamond.setPoint(0, sf::Vector2f(0, -size));   // Top vertex
    icon.diamond.setPoint(1, sf::Vector2f(size, 0));    // Right vertex
    icon.diamond.setPoint(2, sf::Vector2f(0, size));    // Bottom vertex
    icon.diamond.setPoint(3, sf::Vector2f(-size, 0));   // Left vertex

    icon.diamond.setOrigin(0, 0); // Optional: Center the diamond
}


enum ScreenState
{
    POPUP,
    INITIAL,
    GAME,
    CLASSIC,
    NEWMODE,
    SETTINGS,
    MENU,
    EXIT,
    LEADER
};

inline void resizeView(sf::RenderWindow& window, sf::View& view) 
{
    // Get the new window size
    sf::Vector2u windowSize = window.getSize();

    // Calculate the aspect ratio of the window and the game
    float windowAspectRatio = static_cast<float>(windowSize.x) / windowSize.y;
    float gameAspectRatio = 800.f / 600.f;

    // Adjust the viewport to maintain the aspect ratio
    if (windowAspectRatio > gameAspectRatio) {
        // Window is wider, add black bars on the sides
        float newWidth = gameAspectRatio / windowAspectRatio;
        view.setViewport(sf::FloatRect((1.f - newWidth) / 2.f, 0.f, newWidth, 1.f));
    }
    else {
        // Window is taller, add black bars on the top and bottom
        float newHeight = windowAspectRatio / gameAspectRatio;
        view.setViewport(sf::FloatRect(0.f, (1.f - newHeight) / 2.f, 1.f, newHeight));
    }

    view.zoom(1.1f); // Increase the zoom factor slightly to make the screen appear smaller
    window.setView(view);
}

struct ShipsHit
{
    bool hit=0;
    Ship ship;
   
};


// Function to set fullscreen scaling and viewport
inline void applyFullscreenScaling(RenderWindow& window, float originalWidth, float originalHeight, View &view) {
    VideoMode fullscreenMode = VideoMode::getDesktopMode();
    float screenWidth = fullscreenMode.width;
    float screenHeight = fullscreenMode.height;

    // Calculate aspect ratios
    float gameAspectRatio = originalWidth / originalHeight;
    float screenAspectRatio = screenWidth / screenHeight;

    // Determine scaling factor
    float scaleFactor;
    float xOffset = 0, yOffset = 0;

    if (screenAspectRatio > gameAspectRatio) {
        // Fit height and minimize bars on the sides
        scaleFactor = screenHeight / originalHeight;
        xOffset = (screenWidth - (originalWidth * scaleFactor)) / 2.0f;
    }
    else {
        // Fit width and minimize bars on the top/bottom
        scaleFactor = screenWidth / originalWidth;
        yOffset = (screenHeight - (originalHeight * scaleFactor)) / 2.0f;
    }

    // Calculate the new viewport
    float scaledWidth = originalWidth * scaleFactor;
    float scaledHeight = originalHeight * scaleFactor;

    // Create and set a view
    View gameView(FloatRect(0, 0, originalWidth, originalHeight));
    gameView.setViewport(FloatRect(xOffset / screenWidth, yOffset / screenHeight,
    scaledWidth / screenWidth, scaledHeight / screenHeight));
    window.setView(gameView);
}

    



// comp strike functions

inline bool isValid(int x, int y, int SIZE, int parallel[10][10])
{
    return x >= 0 && x < SIZE && y >= 0 && y < SIZE && parallel[x][y] != 0;
}
// Perform a random strike
inline int randomStrike(int SIZE, int  parallel[10][10], int& x, int y)
{
    srand(time(NULL));
    do
    {
        cout << "bhai" << endl;
        x = rand() % 10;
        y = rand() % 10;
    } while (parallel[x][y] == 2); //ensuring that it not generates a number that has alr been hit
    cout << "yaar" << endl;
    return y;

}
// stores possible next hit locations after a successful strike
inline void storeNextHits(int x, int y, int possibleHits[100][2], int& hitCount, Board board, int parallel[10][10], int SIZE, int& lasthit, int& targets) //x, y is of previous hit strike
{
    int nx1 = 1;
    int ny1 = 1;
    int nx2 = 1;
    int ny2 = 1;
    int Y = 1;
    int X = 1;
    if (x < SIZE - 1)//for endpoint
    {
        nx1 = x + 1;
        ny1 = y;
        nx2 = x - 1;
        ny2 = y;
        if (isValid(nx1, ny1, SIZE, parallel))// parallel[nx1][ny1] != 0)
        {
            possibleHits[hitCount][0] = nx1;
            possibleHits[hitCount][1] = ny1;
            hitCount = hitCount + 1;
            targets = targets + 1;
            if (parallel[nx1][ny1] == 1)//vertically stored
            {
                X = nx1;
                //lasthit = 1;
                do
                {
                    if (isValid(X, ny1, SIZE, parallel))
                    {
                        X = X + 1;
                        possibleHits[hitCount][0] = X;
                        possibleHits[hitCount][1] = ny1;
                        hitCount = hitCount + 1;
                        targets = targets + 1;
                    }
                } while (parallel[X][ny1] == 1 && isValid(X, ny1, SIZE, parallel) && x < SIZE - 1);//ADD THIS LOGIC TO ALL
            }

        }
    }
    if (x > 0)
    {
        if (isValid(nx2, ny2, SIZE, parallel)) //&& parallel[nx2][ny2] != 0)
        {
            possibleHits[hitCount][0] = nx2;
            possibleHits[hitCount][1] = ny2;
            hitCount = hitCount + 1;
            targets = targets + 1;
            if (parallel[nx2][ny2] == 1)//vertically stored ooper
            {
                X = nx2;
                lasthit = 1;
                do

                {
                    if (isValid(X, ny2, SIZE, parallel))
                    {
                        X = X - 1;
                        possibleHits[hitCount][0] = X;
                        possibleHits[hitCount][1] = ny2;
                        hitCount = hitCount + 1;
                        targets = targets + 1;
                    }
                } while (parallel[X][ny2] == 1 && isValid(X, ny2, SIZE, parallel) && x > 0);
            }

        }
    }
    nx1 = x;
    ny1 = y + 1;
    nx2 = x;
    ny2 = y - 1;
    if (y < SIZE - 1)
    {
        if (isValid(nx1, ny1, SIZE, parallel))//&& parallel[nx1][ny1] != 0)
        {
            possibleHits[hitCount][0] = nx1;
            possibleHits[hitCount][1] = ny1;
            hitCount = hitCount + 1;
            targets = targets + 1;
            if (parallel[nx1][ny1] == 1)//horizontally stored rightwards
            {
                Y = ny1;
                lasthit = 1;
                do
                {
                    if (isValid(nx1, Y, SIZE, parallel))
                        Y = Y + 1;
                    possibleHits[hitCount][0] = nx1;
                    possibleHits[hitCount][1] = Y;
                    hitCount = hitCount + 1;
                    targets = targets + 1;
                } while (parallel[nx1][Y] == 1 && isValid(nx1, Y, SIZE, parallel) && y < SIZE - 1);
            }

        }
    }
    if (y > 0)
    {
        if (isValid(nx2, ny2, SIZE, parallel))
        {
            possibleHits[hitCount][0] = nx2;
            possibleHits[hitCount][1] = ny2;
            hitCount = hitCount + 1;
            targets = targets + 1;
            if (parallel[nx2][ny2] == 1)//horizontally stored 
            {
                Y = ny2;

                do
                {
                    if (isValid(nx2, Y, SIZE, parallel))
                        Y = Y - 1;
                    possibleHits[hitCount][0] = nx2;
                    possibleHits[hitCount][1] = Y;
                    hitCount = hitCount + 1;
                    targets = targets + 1;
                } while (parallel[nx2][Y] == 1 && isValid(nx2, Y, SIZE, parallel) && y > 0);
            }

        }
    }


}
inline void strike(int possibleHits[100][2], int& hitCount, int& score, Board board, int parallel[10][10], int& targets, int& lasthit, bool placed)
{
    if (hitCount > 0)
    {
        int pointer = 0;
        //getting next possible hit and updating
        int x = possibleHits[pointer][0];
        int y = possibleHits[pointer][1];
        pointer++;


        if (parallel[x][y] == 1)
        {
            parallel[x][y] = 2; //hit
            board.grid[x][y].setColor(Color(139, 0, 0));
            lasthit = 1;
            targets--;
            placed = 1;
        }
        else {
            parallel[x][y] = 2; // miss
            score = score - 1;
            lasthit = 0;
            targets--;
            board.grid[x][y].setColor(Color(169, 169, 169));
            placed = 1;
        }

    }
}
inline bool call(int parallel[10][10], Board& board)
{
    cout << "haajra in call";
    const int SIZE = 10;
    bool placed = 0;

    int score = 100;
    int possibleHits[100][2]; //stores the next possible hits
    int hitCount = 0; // count of possible next hits
    int lasthit = 0;//last hit was succesful or not
    int targets = 0;



    //last hit not successful or (successful and no more targets to be hit)
    if (lasthit == 0 || (lasthit == 1 && targets == 0))

    {

        cout << "in if";
        int x = -1, y = -1;
        cout << "" << x << y << "222";
        y = randomStrike(SIZE, parallel, x, y);//x passed by reference
        cout << x << y << "*******";


        if (parallel[x][y] == 1)
        {

            parallel[x][y] = 2; // mark as hit
            board.grid[x][y].setColor(Color::Red);
            cout << "if statements";
            lasthit = 1;

            storeNextHits(x, y, possibleHits, hitCount, board, parallel, SIZE, lasthit, targets);
            placed = 1;
        }
        else
        {
            parallel[x][y] = 2; // miss
            score -= 1;
            lasthit = 0;
            board.grid[x][y].setColor(Color::Green);
            placed = 1;
            cout << "If statement 2";
        }
    }
    if (lasthit == 1)
    {
        if (targets > 0)
        {
            strike(possibleHits, hitCount, score, board, parallel, targets, lasthit, placed);


        }

    }
    cout << "blagh blagh" << placed << endl;
    return placed;
}
inline void torchEffect(sf::RenderWindow& window, Sprite grid1[10][10], Sprite grid2[10][10]) {
    // Get window size
    sf::Vector2u windowSize = window.getSize();

    // Create a RenderTexture for the blackout effect
    sf::RenderTexture blackoutTexture;
    blackoutTexture.create(windowSize.x, windowSize.y);

    // Create the blackout rectangle
    sf::RectangleShape blackout(sf::Vector2f(windowSize.x, windowSize.y));
    blackout.setFillColor(sf::Color(0, 0, 0, 200)); // Semi-transparent black

    // Spotlight radius
    float torchRadius = 100.0f;

    // Circle shape for the torch effect
    sf::CircleShape torch(torchRadius);
    torch.setFillColor(sf::Color::Transparent); // Hole in the blackout
    torch.setOutlineThickness(torchRadius);
    torch.setOutlineColor(sf::Color::White);
    torch.setOrigin(torchRadius, torchRadius); // Center the torch on the mouse

    // Main game loop
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }
        }

        // Get the mouse position relative to the window
        sf::Vector2i mousePos = sf::Mouse::getPosition(window);
        torch.setPosition(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y));

        // Draw blackout texture with the torch hole
        blackoutTexture.clear(sf::Color::Transparent);
        blackoutTexture.draw(blackout);             // Full blackout
        blackoutTexture.draw(torch, sf::BlendNone); // Erase the circle area
        blackoutTexture.display();

        // Get the blackout sprite from the RenderTexture
        sf::Sprite blackoutSprite(blackoutTexture.getTexture());

        // Clear the window
        window.clear();

        // Draw the grids
        for (int i = 0; i < 10; ++i) {
            for (int j = 0; j < 10; ++j) {
                window.draw(grid1[i][j]);
                window.draw(grid2[i][j]);
            }
        }

        // Overlay the blackout texture
        window.draw(blackoutSprite);

        // Display everything
        window.display();
    }
}


////////////////////////////////////////////////////////////////////////
////////////////////leaderboard functions

inline int getValidIntegerInput(const string& prompt) {
    int value;
    while (true) {
        cout << prompt;
        cin >> value;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "Invalid input! Please enter a valid integer.\n";
        }
        else {
            return value;
        }
    }
}

inline int getValidChoice() {
    int choice;
    while (true) {
        cout << "Enter choice (1-4): ";
        cin >> choice;

        if (cin.fail() || choice < 1 || choice > 4) {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "Invalid input! Please choose a valid option between 1 and 4.\n";
        }
        else {
            return choice;
        }
    }
}

inline void initializeFile(const string& filename, const string& username, int computerScore, int userScore) {
    ofstream file(filename);    // opening the file in write mode (when user wants to go with same name)
    file << "Computer\n" << computerScore << "\n";
    file << username << "\n" << userScore << "\n";
    file.close();
}



inline void updateScores(const string& filename, const string& username, int newComputerScore, int newUserScore) {
    ifstream file(filename);
    string line;
    string tempFile = "temp.txt";  // temp file for updated data

    ofstream temp(tempFile);

    while (getline(file, line)) {
        string playerName = line;
        getline(file, line);
        int playerScore = stoi(line);

        if (playerName == "Computer") {
            playerScore = newComputerScore;
        }
        else if (playerName == username) {
            playerScore = newUserScore;
        }

        temp << playerName << "\n" << playerScore << "\n";
    }

    file.close();
    temp.close();


        remove(filename.c_str());
    rename(tempFile.c_str(), filename.c_str());
}


inline void appendNewPlayer(const string& filename, const string& newPlayerName, int newPlayerScore) {
    ofstream file(filename, ios::app);  // open file in append mode
    file << newPlayerName << "\n" << newPlayerScore << "\n";
    file.close();
}
inline string getUsernameFromFile(string& name) {
    std::ifstream inFile("username.txt");
    std::string username;
    std::string lastUsername;

    if (inFile.is_open()) {
        while (std::getline(inFile, username)) {
            lastUsername = username;  // Keep overwriting until the last line
        }
        inFile.close();
    }
    else {
        std::cerr << "Error opening file to read username!" << std::endl;
    }

    return lastUsername;  // This will contain the last line

}

inline void displayTopScores(const string& filename,string players2[10][2]) {

    string players[10][2];
    ifstream file(filename);
    string line;

 // Stores player names and scores
    int playerCount = 0;
    string firstname, firstscore, secondname, secondscore, thirdname, thirdscore;
    // Reading data from file and storing players and scores
    while (getline(file, line)) {
        players[playerCount][0] = line; // Player name
        getline(file, line);
        players[playerCount][1] = line; // Player score
        playerCount++;
    }

    file.close();

    // Sorting players by score (descending order)
    for (int i = 0; i < playerCount - 1; i++) {
        for (int j = i + 1; j < playerCount; j++) {
            int score1 = stoi(players[i][1]); // Convert score to integer
            int score2 = stoi(players[j][1]);

            if (score1 < score2) { // Swap if the score of player i is less than player j
                string tempName = players[i][0];
                string tempScore = players[i][1];

                players[i][0] = players[j][0];
                players[i][1] = players[j][1];

                players[j][0] = tempName;
                players[j][1] = tempScore;
            }
        }
    }

    // Store top 3 players and their scores in the passed parameters
    if (playerCount > 0) {
        players2[0][0] = players[0][0];
        players2[0][1] =players[0][1];  // 1st place
    }
    else {
        players2[0][0] = "No Player";
        players2[0][1] ="0";
    }

    if (playerCount > 1) {
        players2[1][0] = players[1][0];
        players2[1][1] =players[1][1];  // 2nd place
    }
    else {
        players2[2][0] = "No Player";
        players2[2][1] ="0";
    }

    if (playerCount > 2) {
        players2[3][0] = players[2][0];
        players2[3][1] =players[2][1];  // 3rd place
    }
    else {
        players2[3][0] = "No Player";
        players2[3][1] = "0";
    }

    
}

inline void getLastTwoLines(const std::string& filename, std::string& line1, std::string& line2) {
    std::ifstream file(filename, std::ios::in);
    if (!file.is_open()) {
        std::cerr << "Error: Unable to open file: " << filename << std::endl;
        line1.clear();
        line2.clear();
        return;
    }

    std::string currentLine;
    line1.clear(); // To store the second last line
    line2.clear(); // To store the last line

    while (std::getline(file, currentLine)) {
        line1 = line2; // Move the previous last line to the second last line
        line2 = currentLine; // Update the last line
    }

    file.close();
}

