#include<iostream>
#include"SFML/Graphics.hpp"
#include "myfunctions.h"
#include"common.h"
using namespace std;
using namespace sf;


int main()
{

    RenderWindow window(VideoMode::getDesktopMode(), "Screen Switch Example");

    cout << window.getSize().x << " " << window.getSize().y << endl;
    Board board;
    Texture texture;
    int positions[5][2] = { 0 };
    int positions2[5][2] = { 0 };
    View gameview(sf::FloatRect(0, 0, 800,600));
    window.setView(gameview);
    //globalview.setCenter(400, 300);
    //window.setView(globalview);
    ScreenState currentState = MENU;
    Board board2 = board;

    while (window.isOpen())
    {
        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
            {
                window.close();
            }
        }

        if (currentState == MENU)
        {
            currentState = menu(window, gameview);
            
        }


        if (currentState == CLASSIC)
        {
            currentState = screenOne(window, board, texture, positions, gameview,GAME);
            switch (currentState)
            {
            case GAME:
                currentState = maingame(window, board, texture, positions, gameview);
                break;

            }
        }
        else if (currentState == NEWMODE)
        {
           
            currentState= screenOne(window, board, texture, positions, gameview,INITIAL);
            currentState= screenOne(window, board2, texture, positions2, gameview, NEWMODE);
            
            switch (currentState)
            {
            case NEWMODE:
                currentState =MineMode(window, board,board2, texture, positions,positions2, gameview);
                break;

            }
        }
        else if (currentState == SETTINGS)
        {
            continue;
        }
      /*  else if (currentState == LEADER)
        {
            leader(window,gameview);
        }*/
         
    }
}






