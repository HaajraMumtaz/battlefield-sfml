#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include <cmath>
#include "myfunctions.h"
#include"common.h"
using namespace sf;
using namespace std;

//signatures


enum ScreenState maingame(sf::RenderWindow& window, Board& board, sf::Texture& texture, int positions[5][2], sf::View gameView)
{

	int playerscore;
	ScreenState screenstate = GAME;
	void initializeSpriteGrid(Sprite grid[10][10], Texture & texture, int rows, int cols, float colsize, float rowsize, int offset, float scale, int tempoffsety = 66);
	void draw(RenderWindow & window, Sprite grid[10][10], int rows, int cols, RectangleShape movablesquare);
	RectangleShape setmovablesq(float colsize, float rowsize, float scale);
	RectangleShape setwoodenbox(Texture & texturewood, float width, float height, float positionx, float positiony);
	RectangleShape setmovablesq(float colsize, float rowsize, float scale = 1);
	srand(time(NULL));
	//resizeView(window, gameView);
	RectangleShape overlay;
	const int rows = 10;
	const int cols = 10;
	int width = 800, height = 600;
	bool player = 1;
	//make the texttures
	/*Texture texture;
	if (!texture.loadFromFile("D:\\haajra\\battlefield_PF\\additional files\\field-bg.jpg")) {
		cerr << "Error loading texture!" << endl;
	}*/
	Texture texturewood;
	if (!texturewood.loadFromFile("d:\\haajra\\battlefield_pf\\additional files\\box_texture.jpeg")) {
		cerr << "error loading texture!" << endl;

	}

	Texture background;
	if (!background.loadFromFile("d:\\haajra\\battlefield_pf\\additional files\\black-vector.jpg")) {
		cerr << "error loading texture!" << endl;
	}

	//make the window
	//RenderWindow window(VideoMode(width, height), "Board");

	Sprite grid2[rows][cols];
	int gridval[10][10] = { 0 };
	int gridval2[10][10] = { 0 };
	// Get the texture size
	float textureWidth = static_cast<float>(texture.getSize().x);
	float textureHeight = static_cast<float>(texture.getSize().y);
	// Calculate scale factor to fit the window size

	float InitialscaleX = static_cast<float>(width) / textureWidth / 2;
	float InitialscaleY = static_cast<float>(height) / textureHeight / 2;
	float initialscale = min(InitialscaleX, InitialscaleY);


	float scaleX = static_cast<float>(width) / textureWidth / 3;
	float scaleY = static_cast<float>(height) / textureHeight / 3;
	float scale = std::max(scaleX, scaleY);

	float ratio = scale / initialscale;
	// Set size of each grid cell and general position
	float colsize = textureWidth / (cols);
	float rowsize = textureHeight / (rows);
	int offset = (width / 2 - (textureWidth * scale)) / 2;
	int offsety = (width / 2 + offset);
	cout << ratio << endl;

	int shipnum;
	MarkedPoints CompPoints[5][5];
	MarkedPoints PlayerPoints[5][5];

	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			CompPoints[i][j].Coord = PlayerPoints[i][j].Coord = Vector2i(-1, -1);
			CompPoints[i][j].hit = PlayerPoints[i][j].hit == 0;
		}
	}

	// Initialize the sprites
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			board.grid[i][j].setPosition(j * colsize * scale + offset, i * rowsize * scale + offset + 2);
		}

	}

	bool vertical;
	for (int i = 0; i < 5; i++)
	{
		vertical = rand() & 2;
		ComputerInitialize(gridval2, board, i, vertical, CompPoints);
		cout << "vertical:" << vertical << endl << endl;
	}

	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			cout << gridval2[i][j] << " ";
		}
		cout << endl;
	}
	RectangleShape shipboxx;

	Color greycol = Color(255, 255, 255, 100);
	RectangleShape movablesquare = setmovablesq(colsize, rowsize, scale);
	initializeSpriteGrid(grid2, texture, rows, cols, colsize, rowsize, offset, scale, offsety);
	//Making a box
	int positionybox = (textureHeight * scale) + 2 * offset;
	float gridx = (board.grid[0][0].getPosition().x - 5);
	float gridy = board.grid[0][0].getPosition().y - 5.0;
	Vector2f pos = Vector2f(gridx, gridy);
	float bboxvertical = board.grid[9][0].getPosition().y - pos.y + colsize * scale;
	float bboxhorizontal = board.grid[0][9].getPosition().x - pos.x + rowsize * scale;
	RectangleShape boundingbox = setmovablesq(bboxhorizontal + 5, bboxvertical + 5);
	boundingbox.setPosition(pos);

	float grid2x = (grid2[0][0].getPosition().x - 5);
	float grid2y = grid2[0][0].getPosition().y - 5.0;
	pos = Vector2f(grid2x, grid2y);
	float bbox2vertical = grid2[9][0].getPosition().y - pos.y + colsize * scale;
	float bbox2horizontal = grid2[0][9].getPosition().x - pos.x + rowsize * scale;
	RectangleShape boundingbox2 = setmovablesq(bbox2horizontal + 5, bbox2vertical + 5);
	boundingbox2.setPosition(pos);
	RectangleShape box = setwoodenbox(texturewood, textureWidth * scale, 175, offset, positionybox);
	RectangleShape box2 = setwoodenbox(texturewood, textureWidth * scale, 175, offsety, positionybox);


	float colwidth = (textureWidth * scale)/5;
	float newscale = scale * ratio;
	ShipsHit SetOne[5] =
	{
		  0,Ship(3, rowsize * 2 * scale / 3, rowsize * scale,600, 110), // Ship with 3 segments
		  0,Ship(4, rowsize * 2 * scale / 3, rowsize * scale, 600, 160), // p=(segm,length,width,x pos, y pos)
		  0,Ship(5,rowsize * 2 * scale / 3, rowsize* scale, 600, 210),
		  0,Ship(3, rowsize * 2 * scale / 3, rowsize* scale, 600, 260),
		 0,Ship(2, rowsize * 2 * scale / 3, rowsize * scale, 600, 310)
		 // Ship with 5 segments
	};

	ShipsHit SetTwo[5] =
	{
		  0,Ship(3, rowsize * 2 * scale / 3, rowsize * scale,600, 110), // Ship with 3 segments
		  0,Ship(4,rowsize * 2 * scale / 3, rowsize * scale, 600, 160), // p=(segm,length,width,x pos, y pos)
		  0,Ship(5,rowsize * 2 * scale / 3, rowsize * scale, 600, 210),
		  0,Ship(3, rowsize * scale/2, rowsize * scale, 600, 260),
		 0,Ship(2, rowsize * 2 * scale / 3, rowsize * scale, 600, 310)
		 // Ship with 5 segments
	};
	cout << colsize * scale << "   " << rowsize * scale << "______________________________" << endl;
	// Cache ship bounds and positions
	FloatRect shipBounds[5];
	for (int k = 0; k < 5; k++) {
		board.ships[k].setScale(ratio, ratio);
		int row = positions[k][0];
		int col = positions[k][1];
		board.ships[k].setPosition(
			board.grid[row][col].getPosition().x + (rowsize * scale / 1.5),
			board.grid[row][col].getPosition().y + (colsize * scale / 2)
		);
		SetOne[k].ship.setRotation(90);
		SetOne[k].ship.setPosition(30+(colwidth * k) + box.getPosition().x, box.getPosition().y+20);
		SetTwo[k].ship.setRotation(90);
		SetTwo[k].ship.setPosition(30 + (colwidth * k) + box2.getPosition().x, box2.getPosition().y + 20);
		shipBounds[k] = board.ships[k].getGlobalBounds();
	}


	
	
	// Iterate over the grid
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			FloatRect boxglbl = board.grid[i][j].getGlobalBounds();

			// Check for intersections with all ships
			for (int k = 0; k < 5; k++) {
				float intersectionArea = 0;
				if (DoesIntersect(boxglbl, shipBounds[k], intersectionArea)) {
					if (intersectionArea / (boxglbl.width * boxglbl.height) >= 0.25) {
						gridval[i][j] = 1; // Mark the grid cell as intersected
						int elem = Lastelement(PlayerPoints, k);
						PlayerPoints[k][elem].Coord = Vector2i(i, j);
						cout << "for ship:" << k << " part number:" << elem << " val:" << i << "," << j << endl;
					}
				}
			}
		}
	}

	//Handling Events
	while (window.isOpen()) {
		Event event;
		while (window.pollEvent(event))
		{
			if (event.type == Event::Closed) {
				window.close();
			}

			if (screenstate == GAME)
			{
				if (event.type == Event::MouseButtonPressed && event.mouseButton.button == Mouse::Left)
				{
					Vector2i mousePixelPos = Mouse::getPosition(window); // Mouse position
					Vector2f mousePos = window.mapPixelToCoords(mousePixelPos);
					for (int i = 0; i < rows; i++)
					{
						for (int j = 0; j < cols; j++)
						{
							FloatRect cellBounds = board.grid[i][j].getGlobalBounds();
							FloatRect cellBounds2 = grid2[i][j].getGlobalBounds();
							if (!player)
							{
								if (cellBounds.contains(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y)))
								{
									bool placed = call();
									if (placed)
									{
										bool exists = 0;
										if (AllSunk(PlayerPoints, Vector2i(i, j), shipnum, exists, board) && exists)
										{
											for (int i = 0; i < board.ships[shipnum].getSegments(); i++)
											{
												board.grid[PlayerPoints[shipnum][i].Coord.x][PlayerPoints[shipnum][i].Coord.y].setColor(Color::Black);

											}

											SetOne[shipnum].hit = 1;


											bool hit = 0;

											for (int i = 0; i < 5; i++)
											{
												while (hit)
												{
													if (SetOne[shipnum].hit != 1)
														hit = 0;
												}
											}
											if (hit)
												cout << "player won" << endl;
										}

										gridval[i][j] = 2;
										boundingbox2.setFillColor(Color::Transparent);
										boundingbox.setOutlineColor(greycol);
										boundingbox.setFillColor(greycol);
										movablesquare.setPosition(grid2[0][0].getPosition());
										player = !player;
										break;
									}
								}
							}
							else
							{
								if (cellBounds2.contains(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y)))
								{
									bool placed = 0;
									cout << "here at:" << i << "," << j << endl;
									if (gridval2[i][j] == 0)
									{
										grid2[i][j].setColor(Color::Green);
										placed = 1;
									}
									else if (gridval2[i][j] == 1)
									{
										grid2[i][j].setColor(Color::Red);
										placed = 1;
									}

									if (placed)
									{
										bool exists = 0;
										if (AllSunk(CompPoints, Vector2i(i, j), shipnum, exists, board) && exists)
										{
											for (int i = 0; i < board.ships[shipnum].getSegments(); i++)
											{
												grid2[CompPoints[shipnum][i].Coord.x][CompPoints[shipnum][i].Coord.y].setColor(Color::Black);
											}
											SetTwo[shipnum].hit = 1;



											bool hit = 0;

											for (int i = 0; i < 5; i++)
											{
												while (hit)
												{
													if (SetTwo[shipnum].hit != 1)
														hit = 0;
												}
											}
											if (hit)
												cout << "computer won" << endl;
										}

										gridval2[i][j] = 2;
										boundingbox.setFillColor(Color::Transparent);
										boundingbox2.setOutlineColor(greycol);
										boundingbox2.setFillColor(greycol);
										movablesquare.setPosition(board.grid[0][0].getPosition());
										player = !player;
										break;
									}

								}
							}


						}

					}



				}

				else if (event.type == Event::MouseMoved)
				{
					Vector2i mousePixelPos = Mouse::getPosition(window); // Mouse position
					Vector2f mousePos = window.mapPixelToCoords(mousePixelPos);

					for (int i = 0; i < rows; i++) {
						for (int j = 0; j < cols; j++) {
							FloatRect cellBounds = board.grid[i][j].getGlobalBounds();
							FloatRect cellBounds2 = grid2[i][j].getGlobalBounds();
							if (!player)
							{
								if (cellBounds.contains(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y)))
								{

									movablesquare.setPosition(j * colsize * scale + offset, i * rowsize * scale + offset);

									break;

								}
							}
							else
							{
								if (cellBounds2.contains(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y))) {
									boundingbox.setOutlineColor(greycol);
									boundingbox.setFillColor(greycol);
									movablesquare.setPosition(j * colsize * scale + offsety, i * rowsize * scale + offset);
									break;
								}
							}


						}
					}
				}
				else if (event.type == Event::KeyPressed && event.key.code == Keyboard::Tab)
				{
					screenstate = LEADER;
					return screenstate;
				}
			}
			else if (screenstate == POPUP)
			{
				continue;
			}

			RectangleShape backgroundshape;
			Vector2f dimensions(width, height);
			backgroundshape.setTexture(&background);
			backgroundshape.setSize(dimensions);
			backgroundshape.setPosition(0, 0);
			window.clear();//clearing


			window.draw(backgroundshape);//drawing
			draw(window, board.grid, rows, cols, movablesquare);
			draw(window, grid2, rows, cols, movablesquare);
			window.draw(box);
			window.draw(box2);
			window.draw(boundingbox);
			window.draw(boundingbox2);
			for (int i = 0; i < 5; i++) {

				if (SetOne[i].hit != 1)
					window.draw(SetOne[i].ship);
				if (SetTwo[i].hit != 1)
					window.draw(SetTwo[i].ship);
			}
			/*window.draw(shipboxx);*/
			window.display();//displaying

		}
	}
}

