#ifndef COMMON_H
#define COMMON_H
#include "myfunctions.h"
#include <SFML/Graphics.hpp>
// common.h
enum ScreenState maingame(sf::RenderWindow& window, Board& board, sf::Texture& texture, int positions[5][2], sf::View gameView);
enum ScreenState screenOne(sf::RenderWindow& window, Board& board, sf::Texture& texture, int positions[5][2], sf::View gameView,ScreenState screenstate,bool mission=0);
enum ScreenState menu(sf::RenderWindow& window, sf::View gameView);
enum ScreenState MineMode(sf::RenderWindow& window, Board& board,Board&board2,sf::Texture& texture, int positions[5][2],int positions2[5][2],sf::View gameView);
void leader(RenderWindow& window, View& gameview);


//Sprite grid[10][10];
// COMMON_H
#endif