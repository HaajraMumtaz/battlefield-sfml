#define M_PI 3.14159265358979323846
#include <SFML/Graphics.hpp>
#include<SFML/Audio.hpp>
#include <cmath>                // for cos and sin
#include <vector>
#include<iostream>
#include"common.h"
#include "myfunctions.h"
using namespace sf;
using namespace std;


ScreenState menu(RenderWindow& window, sf::View gameView)
{
    ScreenState screenstate = MENU;

    resizeView(window, gameView);
    window.setView(gameView);
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;
    const int NUM_ICONS = 5;
    const float ICON_RADIUS = 125.0f;
    const float DIAMOND_SIZE = 50.0f;
    const float ROTATION_SPEED = 2.0f; // Speed of rotation (degrees per frame)
    const float ZOOM_SCALE = 1.2f;

    bool showpopup1, showpopup2, showpopup3;
    showpopup1 = showpopup2 = showpopup3 = 0;
    Icon icon;
    window.setFramerateLimit(60);

    // Background texture and sprite
    sf::Texture bgtexture;
    if (!bgtexture.loadFromFile("D:\\haajra\\battlefield_PF\\additional files\\warroomnew2.png")) {
        cout << "texture not found";
    }
    sf::Sprite sprite(bgtexture);

    // Adjust the sprite to fit the entire window
    sprite.setScale(
        static_cast<float>(WINDOW_WIDTH) / bgtexture.getSize().x,
        static_cast<float>(WINDOW_HEIGHT) / bgtexture.getSize().y
    );

    sf::Music backgroundMusic;
    if (!backgroundMusic.openFromFile("D:\\haajra\\battlefield_PF\\additional files\\warsound.mp3")) {
        cout << "font not found";; // Exit if the music file cannot be loaded
    }

    backgroundMusic.setLoop(true);  // Set the music to loop
    backgroundMusic.setVolume(50); // Set volume (optional)
    backgroundMusic.play();        // Start playing the background music

    ////click icon, sound
    //sf::SoundBuffer clickSoundBuffer;   // Buffer to hold the sound data
    //sf::Sound clickSound;               // Sound object that plays the sound

    //if (!clickSoundBuffer.loadFromFile("C:/path/to/click_sound.ogg")) {
    //    return -1; // Exit if the sound cannot be loaded
    //}
    //clickSound.setBuffer(clickSoundBuffer); //associating buffer with sound



    // Load font
    sf::Font font;
    if (!font.loadFromFile("D:\\haajra\\battlefield_PF\\additional files\\GeistMonoBold.ttf")) {
        cout << "font not found"; // Exit if the font cannot be loaded
    }

    // Load Header Font
    sf::Font headerFont;
    if (!headerFont.loadFromFile("D:\\haajra\\battlefield_PF\\additional files\\Stenstreet.ttf")) {
        cout << "font not found";// Exit if the font cannot be loaded
    }

    // Header Text
    sf::Text headerText;
    headerText.setFont(headerFont);
    headerText.setString("BattleScar");
    headerText.setCharacterSize(70);
    headerText.setFillColor(sf::Color::White);
    headerText.setPosition(WINDOW_WIDTH / 2.0f - headerText.getLocalBounds().width / 2.0f, 20);
    headerText.setOutlineThickness(10);
    headerText.setOutlineColor(sf::Color::Black);

    // Center of the window
    sf::Vector2f center(WINDOW_WIDTH / 2.0f, WINDOW_HEIGHT / 2.0f);

    // Labels for each diamond
    String labels[5] = {
        "New Game",
        "Mission Mode",
        "Settings",
        "Instructions",
        "Leaderboard"
    };

    // Load textures for each diamond

    Texture textureFiles;
    if (!textureFiles.loadFromFile("D:\\haajra\\battlefield_PF\\additional files\\button1.jpg"))
    {
        cout << "texture not found";
    }

    // Icons (diamonds) and their associated text
    Icon icons[NUM_ICONS];
    Text texts[NUM_ICONS];

    for (int i = 0; i < NUM_ICONS; ++i) {
        float angle = i * (360.0f / NUM_ICONS) + 90.0f;  // First icon at 90 degrees
        float rad = angle * (M_PI / 180.0f);
        float x = center.x + ICON_RADIUS * std::cos(rad); // Icon x position
        float y = center.y + ICON_RADIUS * std::sin(rad);

        // Create the diamond
        createDiamond(icons[i], DIAMOND_SIZE);

        // Assign the texture to the diamond
        icons[i].texture = &textureFiles;
        icons[i].diamond.setTexture(icons[i].texture);

        icons[i].diamond.setPosition(x, y);
        icons[i].currentAngle = angle;

        // Create the text with a unique label
        texts[i].setFont(font);
        texts[i].setString(labels[i]);
        texts[i].setCharacterSize(20);
        texts[i].setFillColor(sf::Color::White);

        // Center-align text beneath the diamond
        sf::FloatRect textBounds = texts[i].getLocalBounds();
        texts[i].setOrigin(textBounds.left + textBounds.width / 2.0f, textBounds.top + textBounds.height / 2.0f);
        texts[i].setPosition(x, y + DIAMOND_SIZE + 10);
    }

    // Main game loop
    bool isRotating = false;
    int rotatingIconIndex = -1;
    int previousZoomedIndex = -1;

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();


            if (screenstate == MENU)
            {
                // Get the mouse position
                Vector2i mousePixelPos = Mouse::getPosition(window); // Mouse position
                Vector2f mousePos = window.mapPixelToCoords(mousePixelPos);

                // Hover glow effect
                for (int i = 0; i < NUM_ICONS; ++i) {
                    if (!isRotating && icons[i].diamond.getGlobalBounds().contains(mousePos)) {
                        icons[i].diamond.setOutlineColor(sf::Color::Yellow);
                        icons[i].diamond.setOutlineThickness(5.0f);
                    }
                    else if (i != previousZoomedIndex) {
                        icons[i].diamond.setOutlineColor(sf::Color::Transparent);
                        icons[i].diamond.setOutlineThickness(0.0f);
                    }
                }

                // Click to select a diamond
                if (!isRotating && sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                    for (int i = 0; i < NUM_ICONS; ++i) {
                        if (icons[i].diamond.getGlobalBounds().contains(mousePos)) {

                            if (previousZoomedIndex != -1 && previousZoomedIndex != i) {
                                icons[previousZoomedIndex].diamond.setFillColor(sf::Color::White);
                                icons[previousZoomedIndex].diamond.setTexture(icons[previousZoomedIndex].texture);
                                icons[previousZoomedIndex].diamond.setScale(1.0f, 1.0f);
                                icons[previousZoomedIndex].diamond.setOutlineColor(sf::Color::Transparent);
                                icons[previousZoomedIndex].diamond.setOutlineThickness(0.0f);
                                icons[previousZoomedIndex].isZoomedIn = false;
                                /*clickSound.play();*/
                            }
                            else if (previousZoomedIndex == i && previousZoomedIndex != -1)
                            {
                                if (previousZoomedIndex == 0)
                                {

                                    screenstate = CLASSIC;
                                    return screenstate;

                                }
                                else if (previousZoomedIndex == 1)
                                {
                                    screenstate = NEWMODE;
                                    return screenstate;
                                }
                                else if (previousZoomedIndex == 2)
                                {
                                    screenstate = POPUP;
                                    showpopup1 = 1;
                                    showpopup2 = 0;

                                }
                                else if (previousZoomedIndex == 3)
                                {
                                    screenstate = POPUP;
                                    showpopup2 = 1;
                                }
                                else if (previousZoomedIndex == 4)
                                {
                                    screenstate = POPUP;
                                    showpopup3 = 1;
                                }
                            }

                            isRotating = true;
                            rotatingIconIndex = i;
                            icons[i].diamond.setFillColor(sf::Color::Green);
                            icons[i].diamond.setScale(ZOOM_SCALE, ZOOM_SCALE);
                            icons[i].diamond.setOutlineColor(sf::Color::Yellow);
                            icons[i].diamond.setOutlineThickness(5.0f);
                            icons[i].isZoomedIn = true;
                            previousZoomedIndex = i;
                            cout << i;
                            break;
                        }
                    }
                }

                if (isRotating) {
                    float targetAngle = -270.0f;
                    float& currentAngle = icons[rotatingIconIndex].currentAngle;
                    float diff = targetAngle - currentAngle;
                    if (diff > 180.0f) diff -= 360.0f;
                    if (diff < -180.0f) diff += 360.0f;

                    if (std::abs(diff) > ROTATION_SPEED) {
                        currentAngle += (diff > 0 ? ROTATION_SPEED : -ROTATION_SPEED);
                    }
                    else {
                        currentAngle = targetAngle;
                        isRotating = false;
                        icons[rotatingIconIndex].diamond.setFillColor(sf::Color::White);
                    }

                    for (int i = 0; i < NUM_ICONS; ++i) {
                        float angleStep = 360.0f / NUM_ICONS;
                        icons[i].currentAngle = fmod(currentAngle + (i - rotatingIconIndex) * angleStep + 360.0f, 360.0f);
                        float rad = icons[i].currentAngle * (M_PI / 180.0f);
                        float x = center.x + ICON_RADIUS * std::cos(rad);
                        float y = center.y + ICON_RADIUS * std::sin(rad);

                        icons[i].diamond.setPosition(x, y);
                        texts[i].setPosition(x, y + DIAMOND_SIZE + 10);



                    }
                }

            }

            else if (screenstate == POPUP)
            {
                if (showpopup1)
                {
                    continue;
                }
                else if (showpopup2)
                {
                    continue;
                }
                else if (showpopup3)
                {
                    continue;
                }
            }



            // Render everything
            window.clear();
            window.draw(sprite);
            window.draw(headerText);

            for (int i = 0; i < NUM_ICONS; ++i) {
                window.draw(icons[i].diamond);
                window.draw(texts[i]);
            }

            window.display();
        }
    }
}




