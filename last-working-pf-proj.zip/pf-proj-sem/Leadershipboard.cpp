//#include <SFML/Graphics.hpp>
//#include <SFML/Window.hpp>
//#include <SFML/Audio.hpp>
//#include <iostream>
//#include "myfunctions.h"
//#include"common.h"
//
//void leader(RenderWindow &window,View &gameview)
//{
//    // Create a window with size 800x600 and title "Leaderboard"
//
//
//    // Load texture for window background
//    sf::Texture windowTexture;
//    if (!windowTexture.loadFromFile("D:\\haajra\\battlefield_PF\\additional files\\leadertexture.jpg")) {
//        std::cerr << "Error loading background texture!" << std::endl;
//   
//    }
//
//    // Create a sprite for the background texture
//    sf::Sprite background(windowTexture);
//    background.setScale(
//        (float)window.getSize().x / windowTexture.getSize().x,
//        (float)window.getSize().y / windowTexture.getSize().y
//    );
//
//    // Load a font for the text (ensure the font is in the correct path)
//    sf::Font font;
//    if (!font.loadFromFile("D:\\haajra\\battlefield_PF\\additional files\\GeistMonoBold.ttf")) {
//        std::cerr << "Error loading font!" << std::endl;
//     
//    }
//
//    // Load a different font for the heading (use a different path for the heading font if needed)
//    sf::Font headingFont;
//    if (!headingFont.loadFromFile("D:\\haajra\\battlefield_PF\\additional files\\GeistMonoBold.ttf")) {
//        std::cerr << "Error loading heading font!" << std::endl;
//    
//    }
//    applyFullscreenScaling(window, 800, 600, gameview);
//    // Heading text (brown color and different font)
//    sf::Text heading;
//    heading.setFont(headingFont);  // Using the new font for heading
//    heading.setString("Leaderboard");
//    heading.setCharacterSize(48);
//    heading.setFillColor(sf::Color(139, 69, 19));  // Brown color
//    heading.setPosition(300, 20);
//
//    // Create the table (2 columns, 3 rows)
//    sf::RectangleShape tableBackground(sf::Vector2f(600, 300));
//    tableBackground.setFillColor(sf::Color::White);
//    tableBackground.setPosition(100, 120);  // Moved up
//
//    // Create table columns and rows
//    sf::VertexArray tableLines(sf::Lines, 4);
//
//    // Column lines (vertical)
//    tableLines[0].position = sf::Vector2f(300, 120);  // Adjusted
//    tableLines[1].position = sf::Vector2f(300, 420);  // Adjusted
//
//    tableLines[2].position = sf::Vector2f(500, 120);  // Adjusted
//    tableLines[3].position = sf::Vector2f(500, 420);  // Adjusted
//
//    // Row lines (horizontal)
//    sf::VertexArray rowLines(sf::Lines, 4);
//    rowLines[0].position = sf::Vector2f(100, 220);  // Adjusted
//    rowLines[1].position = sf::Vector2f(700, 220);  // Adjusted
//
//    rowLines[2].position = sf::Vector2f(100, 320);  // Adjusted
//    rowLines[3].position = sf::Vector2f(700, 320);  // Adjusted
//
//    // Data to be displayed in the table
//    std::string names[3] = { "Player 1", "Player 2", "Player 3" };
//    int scores[3] = { 100, 200, 300 };
//
//    // Create the text for table content
//    sf::Text tableText[6];
//    for (int i = 0; i < 6; ++i) {
//        tableText[i].setFont(font);
//        tableText[i].setCharacterSize(24);
//        tableText[i].setFillColor(sf::Color(139, 69, 19)); // Brown color
//    }
//
//    // Set table text positions and values
//    for (int i = 0; i < 3; ++i) {
//        tableText[i].setString(names[i]);
//        tableText[i].setPosition(120.f, 140.f + (i * 100));  // Adjusted
//    }
//
//    for (int i = 3; i < 6; ++i) {
//        tableText[i].setString(std::to_string(scores[i - 3]));
//        tableText[i].setPosition(520.f, 140.f + ((i - 3) * 100));  // Adjusted
//    }
//
//    // Create buttons
//    sf::RectangleShape resumeButton(sf::Vector2f(200, 50));
//    resumeButton.setFillColor(sf::Color(139, 69, 19));  // Brown button
//    resumeButton.setPosition(150, 400);  // Moved up
//
//    sf::Text resumeText;
//    resumeText.setFont(font);
//    resumeText.setString("Resume Game");
//    resumeText.setCharacterSize(24);
//    resumeText.setFillColor(sf::Color::White);
//    resumeText.setPosition(180, 410);
//
//    sf::RectangleShape newGameButton(sf::Vector2f(200, 50));
//    newGameButton.setFillColor(sf::Color(139, 69, 19));  // Brown button
//    newGameButton.setPosition(450, 400);  // Moved up
//
//    sf::Text newGameText;
//    newGameText.setFont(font);
//    newGameText.setString("New Game");
//    newGameText.setCharacterSize(24);
//    newGameText.setFillColor(sf::Color::White);
//    newGameText.setPosition(480, 410);
//
//    // Exit Button (new button)
//    sf::RectangleShape exitButton(sf::Vector2f(200, 50));
//    exitButton.setFillColor(sf::Color(255, 0, 0));  // Red button
//    exitButton.setPosition(300, 470);  // Placed between Resume and New Game
//
//    sf::Text exitText;
//    exitText.setFont(font);
//    exitText.setString("Exit");
//    exitText.setCharacterSize(24);
//    exitText.setFillColor(sf::Color::White);
//    exitText.setPosition(355, 480);  // Centered
//
//    // New Name and Same Name buttons (added the declaration and initialization)
//    sf::RectangleShape newNameButton(sf::Vector2f(300, 70));
//    newNameButton.setFillColor(sf::Color(139, 69, 19));
//    newNameButton.setPosition(250, 230);  // Adjusted position to be higher for better centering
//
//    sf::Text newNameText;
//    newNameText.setFont(font);
//    newNameText.setString("New Name");
//    newNameText.setCharacterSize(36);
//    newNameText.setFillColor(sf::Color::White);
//    newNameText.setPosition(280, 240);  // Adjusted position
//
//    sf::RectangleShape sameNameButton(sf::Vector2f(300, 70));
//    sameNameButton.setFillColor(sf::Color(139, 69, 19));
//    sameNameButton.setPosition(250, 320);  // Adjusted position to be higher for better centering
//
//    sf::Text sameNameText;
//    sameNameText.setFont(font);
//    sameNameText.setString("Same Name");
//    sameNameText.setCharacterSize(36);
//    sameNameText.setFillColor(sf::Color::White);
//    sameNameText.setPosition(270, 330);  // Adjusted position
//
//    bool additionalButtonsVisible = false;
//    string filename = "leaderboard.txt";
//    string username = "Player1";  // default username for initialization
//    int computerScore = 100, userScore = 80;
//    int choice;
//
//
//    // Game loop
//    while (window.isOpen()) {
//        sf::Event event;
//        while (window.pollEvent(event)) {
//            if (event.type == sf::Event::Closed) {
//                window.close();
//            }
//
//            // Handle button clicks
//            if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
//                Vector2i mousePixelPos = Mouse::getPosition(window); // Mouse position
//                Vector2f mousePos = window.mapPixelToCoords(mousePixelPos);
//
//                // Check if 'Resume Game' is clicked
//                if (resumeButton.getGlobalBounds().contains((sf::Vector2f)mousePos)) {
//                    std::cout << "Resume Game button clicked.\n";
//                    additionalButtonsVisible = true;
//                }
//
//                // Check if 'New Game' is clicked
//                if (newGameButton.getGlobalBounds().contains((sf::Vector2f)mousePos)) {
//                    std::cout << "New Game button clicked.\n";
//                    // Restart game logic here
//                    cout << "Resetting leaderboard...\n";
//                    cout << "Enter new username: ";
//                    cin >> username;
//                    computerScore = getValidIntegerInput("Enter computer score: ");
//                    userScore = getValidIntegerInput("Enter your score: ");
//                    initializeFile(filename, username, computerScore, userScore);
//                }
//
//                // Check if 'Exit' button is clicked
//                if (exitButton.getGlobalBounds().contains((sf::Vector2f)mousePos)) {
//                    std::cout << "Exit button clicked.\n";
//                    window.close();  // Close the window and exit the application
//                }
//
//                // Check if 'New Name' is clicked (if additional buttons are visible)
//                if (additionalButtonsVisible && newNameButton.getGlobalBounds().contains((sf::Vector2f)mousePos)) {
//
//
//                    std::cout << "New Name button clicked.\n";
//                    additionalButtonsVisible = false;
//                    string newPlayerName;
//                    int newPlayerScore;
//
//                 
//                    // Append the new player and their score to the file
//                    appendNewPlayer(filename, newPlayerName, newPlayerScore);
//
//                    // Update the username to the new player's name
//                    username = newPlayerName;
//
//                    // Update the scores for the new player and the computer
//                    updateScores(filename, username, computerScore, newPlayerScore);
//                }
//
//                // Check if 'Same Name' is clicked (if additional buttons are visible)
//                if (additionalButtonsVisible && sameNameButton.getGlobalBounds().contains((sf::Vector2f)mousePos)) {
//                    std::cout << "Same Name button clicked.\n";
//                    additionalButtonsVisible = false;
//                    userScore = getValidIntegerInput("Enter your new score: ");
//                    computerScore = getValidIntegerInput("Enter new computer score: ");
//                    updateScores(filename, username, computerScore, userScore);
//
//                }
//            }
//        }
//
//        // Clear the window
//        window.clear();
//
//        // Draw everything
//        window.draw(background);
//
//        // Draw the heading and table if the additional buttons are not visible
//        if (!additionalButtonsVisible) {
//            window.draw(heading);
//            window.draw(tableBackground);
//            window.draw(tableLines);
//            window.draw(rowLines);
//
//            // Draw table content
//            for (int i = 0; i < 6; ++i) {
//                window.draw(tableText[i]);
//            }
//
//            // Draw other buttons (Resume and New Game)
//            window.draw(resumeButton);
//            window.draw(resumeText);
//            window.draw(newGameButton);
//            window.draw(newGameText);
//        }
//
//        // Draw Exit button
//        window.draw(exitButton);
//        window.draw(exitText);
//
//        // Draw the new buttons if they are visible
//        if (additionalButtonsVisible) {
//            window.draw(newNameButton);
//            window.draw(newNameText);
//            window.draw(sameNameButton);
//            window.draw(sameNameText);
//        }
//
//        // Display the contents of the window
//        window.display();
//    }
//}